 "use client";
import {useMemo,useState} from "react";
type Character={id:number,name:string,emoji:string};
export default function Home(){
 const [characters,setCharacters]=useState<Character[]>([{id:1,name:"Meu personagem",emoji:"🧔"},{id:2,name:"Personagem 02",emoji:"👨🏻‍🎤"},{id:3,name:"Personagem 03",emoji:"👩🏻"},{id:4,name:"Personagem 04",emoji:"🧑🏽"}]);
 const [selected,setSelected]=useState(1),[video,setVideo]=useState<File|null>(null),[image,setImage]=useState<File|null>(null),[prompt,setPrompt]=useState(""),[duration,setDuration]=useState("5"),[ratio,setRatio]=useState("9:16"),[model,setModel]=useState("Wan 3.0 Prime · 1080p"),[busy,setBusy]=useState(false),[notice,setNotice]=useState(""),[tab,setTab]=useState("Estúdio"),[url,setUrl]=useState("");
 const price=useMemo(()=>Number(duration)*0.52,[duration]);
 async function generate(){setNotice(""); if(!prompt.trim()){setNotice("Escreva um prompt antes de gerar.");return;} setBusy(true); try { const fd=new FormData(); fd.append("prompt",prompt);fd.append("duration",duration);fd.append("ratio",ratio);fd.append("model",model);fd.append("character",characters.find(c=>c.id===selected)?.name||"");if(video)fd.append("video",video);if(image)fd.append("image",image); const r=await fetch("/api/generate",{method:"POST",body:fd});const d=await r.json();setNotice(d.message||"Não foi possível iniciar a geração."); }catch(e){setNotice("Falha ao contactar o servidor.");}finally{setBusy(false);} }
 function addCharacter(){const name=window.prompt("Nome do personagem:");if(name?.trim()){const c={id:Date.now(),name:name.trim(),emoji:"✨"};setCharacters([...characters,c]);setSelected(c.id);}}
 return <main>
 <header><div className="brand"><span className="brandMark">C</span> Character <small>WAN STUDIO</small></div><nav>{["Estúdio","Personagens","Fila","Galeria","Configurações"].map(x=><button className={tab===x?"nav active":"nav"} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav><div className="account"><span className="apiDot"></span> AIQOU <button className="exit" onClick={()=>setNotice("Configure sua chave no arquivo .env.local.")}>Configurar API</button></div></header>
 <div className="noticebar"><span>Estúdio independente conectado à estrutura da AIQOU</span><span className="rightnote">Modelos WAN · custo estimado em USD</span></div>
 {tab==="Estúdio"? <section className="workspace">
 <article className="panel characters"><div className="panelhead"><b><i>1</i> Personagem</b><span>{characters.length} disponíveis · <u onClick={()=>setSelected(0)}>limpar</u></span></div>
 <div className="subhead">Meus personagens <button onClick={addCharacter}>+ Novo</button></div>
 <div className="search">⌕ <input placeholder="Buscar personagem" onChange={e=>{}} /></div>
 <div className="filters"><span className="chip selected">Todos</span><span className="chip">★ Favoritos</span><span className="chip">Criados</span></div>
 <div className="charactergrid"><button className="createTile" onClick={addCharacter}><strong>＋</strong><span>Criar personagem</span></button>{characters.map(c=><button key={c.id} onClick={()=>setSelected(c.id)} className={"character "+(selected===c.id?"chosen":"")}><div className="avatar">{c.emoji}</div><span>{c.name}</span>{selected===c.id&&<b className="check">✓</b>}</button>)}</div>
 <p className="hint">Selecione um personagem para organizar suas referências. A troca de personagem no vídeo depende do suporte do modelo e da API.</p></article>
 <article className="panel source"><div className="panelhead"><b><i>2</i> Vídeo base</b><span>opcional</span></div>
 <label className="drop"><input type="file" accept="video/mp4,video/quicktime,video/webm" onChange={e=>setVideo(e.target.files?.[0]||null)}/><strong>＋</strong><b>{video?video.name:"Solte ou escolha um vídeo"}</b><small>MP4, MOV ou WEBM</small></label>
 <div className="or">OU</div><div className="urlrow"><input value={url} onChange={e=>setUrl(e.target.value)} placeholder="Cole o link de um vídeo"/><button onClick={()=>setNotice("O envio por link será habilitado conforme o endpoint da AIQOU.")}>Usar link</button></div>
 <div className="divider"></div><div className="panelhead compact"><b>Imagem de referência</b><span>opcional</span></div>
 <label className="drop smallDrop"><input type="file" accept="image/*" onChange={e=>setImage(e.target.files?.[0]||null)}/><strong>＋</strong><b>{image?image.name:"Adicionar imagem de referência"}</b><small>PNG, JPG ou WEBP</small></label>
 <p className="hint">Use uma imagem para orientar a aparência ou composição, conforme os recursos aceitos pelo modelo WAN.</p></article>
 <article className="panel generate"><div className="panelhead"><b><i>3</i> Gerar</b><span className="wanbadge">WAN</span></div>
 <label className="fieldlabel">Modelo</label><select value={model} onChange={e=>setModel(e.target.value)}><option>Wan 3.0 Prime · 1080p</option><option>Outro modelo WAN (configurar ID)</option></select>
 <div className="two"><div><label className="fieldlabel">Duração</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="5">5 segundos</option><option value="10">10 segundos</option></select></div><div><label className="fieldlabel">Proporção</label><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>9:16</option><option>16:9</option><option>1:1</option></select></div></div>
 <div className="prompthead"><label className="fieldlabel">Prompt</label><span>Descreva o resultado</span></div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Descreva o movimento, a cena, a câmera, a iluminação e o que deve acontecer no vídeo..."/>
 <div className="prompttip">Dica: seja específico sobre movimento, enquadramento, iluminação e continuidade visual.</div>
 <div className="estimate"><span>Custo estimado</span><b>${price.toFixed(2)} USD</b><small>Estimativa baseada em US$ 0,52 por segundo. Confirme a tarifa real na AIQOU.</small></div>
 <button className="generateBtn" disabled={busy} onClick={generate}>{busy?"Enviando...":"✦  Gerar vídeo"}</button>
 {notice&&<div className="notice">{notice}</div>}
 <p className="disclaimer">A geração real será ativada após configurar o identificador do modelo WAN e os endpoints exatos da API AIQOU.</p></article>
 </section>:<section className="placeholder"><h2>{tab}</h2><p>Esta área faz parte da estrutura do estúdio e será conectada às funções de personagens, fila, galeria e configurações.</p><button onClick={()=>setTab("Estúdio")}>Voltar ao estúdio</button></section>}
 <footer>CHARACTER WAN STUDIO <span>Interface independente · API AIQOU</span></footer>
 </main>
}
