import './globals.css';
export const metadata = { title: 'Character WAN Studio', description: 'Estúdio de criação de vídeos com modelos WAN via AIQOU' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="pt-BR"><body>{children}</body></html>; }
