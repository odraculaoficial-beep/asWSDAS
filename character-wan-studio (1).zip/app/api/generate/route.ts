import {NextResponse} from 'next/server';
export async function POST(req:Request){
 const form=await req.formData();
 const prompt=String(form.get('prompt')||'');
 if(!prompt.trim()) return NextResponse.json({message:'Prompt obrigatório.'},{status:400});
 const base=process.env.AIQOU_BASE_URL, key=process.env.AIQOU_API_KEY, model=process.env.AIQOU_WAN_MODEL_ID, path=process.env.AIQOU_VIDEO_CREATE_PATH;
 if(!base||!key||!model||!path) return NextResponse.json({message:'A interface está pronta, mas a geração ainda não foi conectada: faltam o ID exato do modelo WAN e o endpoint de criação de vídeo da AIQOU. Configure no .env.local após confirmar a documentação.'},{status:501});
 // A chamada externa é intencionalmente bloqueada até confirmar o formato oficial do payload da AIQOU.
 return NextResponse.json({message:'Configuração detectada. O formato do payload ainda precisa ser ajustado à documentação oficial da AIQOU.'},{status:501});
}
