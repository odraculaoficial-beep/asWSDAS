# Character Studio — projeto inicial

Interface web inspirada no setup enviado: barra superior, aviso de créditos e três painéis lado a lado (Personagem → Vídeo base → Gerar), com rolagem horizontal no celular para preservar o layout.

## Como publicar pelo iPhone
1. Baixe e extraia o ZIP.
2. No GitHub, crie um repositório vazio.
3. Envie os arquivos e pastas deste projeto para o repositório (Add file → Upload files).
4. Em https://vercel.com, entre com GitHub e importe esse repositório.
5. Em Project Settings → Environment Variables, adicione:
   - AIQOU_BASE_URL = https://aiqou.com/v1
   - AIQOU_API_KEY = sua chave secreta (NUNCA coloque no código ou no GitHub)
   - AIQOU_MODELS_PATH = rota de listagem de modelos confirmada na documentação
   - AIQOU_GENERATE_PATH = rota de geração confirmada na documentação
6. Faça Deploy.

## Importante sobre a integração
O print da Aiqou mostra o endereço base e o método Bearer, mas não mostra as rotas nem o formato de geração.
Por segurança, a API é chamada por rotas de servidor (`app/api/...`) e a chave fica em variável de ambiente.
Os caminhos `/models` e `/videos/generations` são apenas valores iniciais de exemplo; confirme os caminhos e os campos exigidos na documentação Aiqou antes de usar.
O upload de mídia também precisa ser adaptado ao fluxo oficial de upload da Aiqou. A interface já permite selecionar imagem/vídeo, mas o envio ainda está sinalizado como pendente até conhecermos esse formato.
A galeria, biblioteca de personagens e fila persistente são estrutura visual inicial; ainda não há armazenamento de conta/usuários.
