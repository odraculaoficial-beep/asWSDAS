import "./globals.css";
export const metadata = { title: "Character Studio", description: "Estúdio de criação de vídeos com IA" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
