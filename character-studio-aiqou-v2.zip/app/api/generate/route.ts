import { NextResponse } from "next/server";
export async function POST(req:Request){
  const base=process.env.AIQOU_BASE_URL,key=process.env.AIQOU_API_KEY,path=process.env.AIQOU_GENERATE_PATH;
  if(!base||!key||!path)return NextResponse.json({error:"Configure a API Aiqou no servidor."},{status:500});
  try{
    const f=await req.formData(),model=String(f.get("model")||""),prompt=String(f.get("prompt")||"");
    if(!model||!prompt)return NextResponse.json({error:"Modelo e prompt são obrigatórios."},{status:400});
    const media=f.get("media") as File|null;
    if(media&&media.size)return NextResponse.json({error:"O envio de mídia precisa ser ajustado ao formato de upload exigido pela documentação Aiqou. A interface já recebe o arquivo."},{status:501});
    // Ajuste os campos abaixo conforme o endpoint oficial da Aiqou.
    const r=await fetch(base.replace(/\/$/,"")+(path.startsWith("/")?path:"/"+path),{
      method:"POST",headers:{Authorization:"Bearer "+key,"Content-Type":"application/json"},
      body:JSON.stringify({model,prompt})
    });
    const d=await r.json();return NextResponse.json(d,{status:r.status});
  }catch{return NextResponse.json({error:"Falha ao contactar a API."},{status:500});}
}
