import { NextResponse } from "next/server";
export async function GET(){
  const base=process.env.AIQOU_BASE_URL, key=process.env.AIQOU_API_KEY, path=process.env.AIQOU_MODELS_PATH;
  if(!base||!key||!path)return NextResponse.json({models:["wan-3.0"]});
  try{
    const r=await fetch(base.replace(/\/$/,"")+(path.startsWith("/")?path:"/"+path),{headers:{Authorization:"Bearer "+key},cache:"no-store"});
    const d=await r.json();if(!r.ok)return NextResponse.json({models:["wan-3.0"],error:"Falha ao listar modelos"});
    const arr=d.data||d.models||d;
    const models=Array.isArray(arr)?arr.map((x:any)=>typeof x==="string"?x:(x.id||x.name||x.model)).filter(Boolean):["wan-3.0"];
    return NextResponse.json({models});
  }catch{return NextResponse.json({models:["wan-3.0"]});}
}
