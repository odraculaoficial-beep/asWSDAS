 "use client";
import { useEffect, useState } from "react";

const characters = [
  ["Novo personagem","/characters/new.jpg"],["Abu Shalab","/characters/abu-shalab.jpg"],
  ["Abu Yalla","/characters/abu-yalla.jpg"],["Arthur Teddington","/characters/arthur.jpg"],
  ["Barnaby Nugget","/characters/barnaby.jpg"],["Bill Smith","/characters/bill.jpg"],
  ["Ched Chin","/characters/ched.jpg"],["Cosmo Boxwell","/characters/cosmo.jpg"],
  ["Derek Mercer","/characters/derek.jpg"],["Don Nuger","/characters/don.jpg"],
  ["Dr. Dofenheimritz","/characters/dr.jpg"]
];

export default function Home() {
  const [tab,setTab]=useState("Estúdio");
  const [selected,setSelected]=useState("Novo personagem");
  const [model,setModel]=useState("wan-3.0");
  const [models,setModels]=useState<string[]>(["wan-3.0"]);
  const [prompt,setPrompt]=useState("");
  const [file,setFile]=useState<File|null>(null);
  const [video,setVideo]=useState("");
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("Escolha um modelo e descreva a cena para começar.");
  const [promptOn,setPromptOn]=useState(true);

  useEffect(()=>{fetch("/api/models").then(r=>r.json()).then(d=>{
    if(Array.isArray(d.models)&&d.models.length){setModels(d.models.map((m:any)=>typeof m==="string"?m:(m.id||m.name)).filter(Boolean));}
  }).catch(()=>{});},[]);

  async function generate(){
    if(!prompt.trim()){setMessage("Escreva um prompt antes de gerar.");return;}
    if(!file){setMessage("Adicione um vídeo base ou imagem de referência, se o modelo exigir.");}
    setBusy(true);setVideo("");setMessage("Enviando solicitação para a API…");
    try{
      const fd=new FormData();fd.append("model",model);fd.append("prompt",prompt);
      fd.append("character",selected);if(file)fd.append("media",file);
      const r=await fetch("/api/generate",{method:"POST",body:fd});const d=await r.json();
      if(!r.ok)throw new Error(d.error||"Não foi possível iniciar a geração.");
      const url=d.video_url||d.url||d.output?.[0]||d.data?.video_url;
      if(url){setVideo(url);setMessage("Vídeo recebido com sucesso.");}
      else setMessage("A API respondeu. Verifique o retorno abaixo: "+JSON.stringify(d).slice(0,350));
    }catch(e:any){setMessage(e.message||"Erro ao gerar.");}finally{setBusy(false);}
  }

  return <main className="app">
    <header className="nav">
      <div className="logo">Character</div>
      <nav>{["Estúdio","Personagens","Fila","Galeria","Configurações"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav>
      <div className="account"><span>Higgsfield 1</span><button>Sair</button></div>
    </header>
    <div className="notice">Seu estúdio de criação está pronto para conectar à API Aiqou. <span>Configure a chave no servidor para gerar vídeos.</span></div>
    <section className="columns">
      <section className="column people">
        <div className="colhead"><b><i>1</i> Personagem</b><small>1 escolhido · <u onClick={()=>setSelected("")}>limpar</u></small></div>
        <div className="subhead">Novo personagem <span>ficha</span></div>
        <div className="angles">{["Frente","Card","Perfil","3/4 direita"].map((x,i)=><div className="angle" key={x}><div className="anglePic">{["◉","▣","◐","◒"][i]}</div><small>{x}</small></div>)}</div>
        <input className="search" placeholder="⌕  Buscar personagem"/>
        <div className="filters"><button className="chosen">Todos</button><button>★</button><button>Biblioteca</button><button>Criados</button></div>
        <div className="characterGrid">
          <button className="createCard" onClick={()=>setSelected("Novo personagem")}><strong>＋</strong><small>Criar</small></button>
          {characters.slice(1).map((c,i)=><button key={c[0]} onClick={()=>setSelected(c[0])} className={"character "+(selected===c[0]?"selected":"")}>
            <div className={"avatar avatar"+i}>{["👨🏻","🧔🏻","👨🏼‍🦰","🐶","👨🏻‍🦳","💪","👨🏽","🧑🏻","👨🏻‍🦰","🧑🏼"][i]}</div><b>{c[0]}</b>{selected===c[0]&&<em>✓</em>}
          </button>)}
        </div>
      </section>
      <section className="column base">
        <div className="colhead"><b><i>2</i> Vídeo base</b><small>arraste para a janela</small></div>
        <label className="drop"><input type="file" accept="video/*,image/*" onChange={e=>setFile(e.target.files?.[0]||null)}/><strong>＋</strong><b>{file?file.name:"Solte ou escolha arquivos"}</b><small>Imagem ou vídeo de referência</small><small>MP4, MOV, WEBM, JPG ou PNG</small></label>
        <div className="linkrow"><input placeholder="Cole o link de uma mídia (opcional)"/><button>Baixar</button></div>
        <div className="baseHint">Adicione uma imagem para image-to-video ou um vídeo base, conforme o modelo selecionado.</div>
      </section>
      <section className="column generateCol">
        <div className="colhead"><b><i>3</i> Gerar</b></div>
        <label className="fieldLabel">Modelo</label>
        <select value={model} onChange={e=>setModel(e.target.value)}>{models.map(m=><option key={m}>{m}</option>)}</select>
        <div className="modelMeta">Modelo selecionado · API Aiqou</div>
        <div className="promptHead"><b>PROMPT</b><button onClick={()=>setPromptOn(!promptOn)}>{promptOn?"●":"○"}</button></div>
        {promptOn&&<textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Descreva a cena, o movimento, a câmera, a iluminação e o estilo…" rows={7}/>}
        <p className="fineprint">Os parâmetros disponíveis dependem do modelo e da documentação da API.</p>
        <button className="run" onClick={generate} disabled={busy}>{busy?"ENVIANDO…":"✦  GERAR VÍDEO"}</button>
        <p className="status">{message}</p>
        {video&&<video className="result" src={video} controls playsInline/>}
      </section>
    </section>
    <footer>CHARACTER STUDIO <span>Interface independente · API Aiqou</span></footer>
  </main>;
}
